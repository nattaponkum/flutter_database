import 'dart:ffi';
import 'dart:io';
import 'package:flutter_database/models/TransactionItem.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sembast/sembast.dart';
import 'package:sembast/sembast_io.dart';

class TransactionDB{

  String dbName;
  //account1.db

  TransactionDB(this.dbName);

  Future<Database> openDatabase() async{
    Directory appDirectory = await getApplicationDocumentsDirectory();

    String dbLocation = join(appDirectory.path, dbName);

    //create db
    DatabaseFactory dbFactory = databaseFactoryIo;
    Future<Database> db = dbFactory.openDatabase(dbLocation);
    return db;
  }

  insertData(TransactionItem trans) async{
    var db = await this.openDatabase();
    var store = intMapStoreFactory.store("expense");

    var keyId = await store.add(db, {
      "title": trans.title,
      "amount": trans.amount,
      "date": trans.date.toIso8601String()
    });
    print("$keyId");
    db.close();
  }

  Future<List<TransactionItem>> loadAllData() async{
    var db = await this.openDatabase();
    var store = intMapStoreFactory.store("expense");

    var snapshot = await store.find(db);
    print(snapshot);

    List<TransactionItem> transactions = [];

    for ( var item in snapshot){
      String title = item['title'].toString();
      double amount = double.parse(item['amount'].toString());
      DateTime date = DateTime.parse(item['date'].toString());

      TransactionItem trans = TransactionItem(title: title, amount: amount, date: date);

      transactions.add(trans);
    }
    db.close();
    return transactions;
  }

}