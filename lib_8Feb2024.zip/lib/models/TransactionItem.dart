class TransactionItem{
  String title;
  double amount;
  DateTime date;

  TransactionItem({required this.title, required this.amount, required this.date});
}